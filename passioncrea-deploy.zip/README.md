# PassionCréa - Déploiement Apache2

## Installation Automatique (Linux)

```bash
# 1. Extraire le ZIP sur le serveur
unzip passioncrea-deploy.zip -d /var/www/

# 2. Configurer les permissions
sudo chown -R www-data:www-data /var/www/passioncrea/
sudo chmod -R 755 /var/www/passioncrea/

# 3. Activer le site
sudo a2ensite passioncrea
sudo a2enmod rewrite headers expires deflate
sudo systemctl reload apache2
```

## Installation Manuelle

### 1. Prérequis Apache2
```bash
sudo apt update
sudo apt install apache2
sudo a2enmod rewrite
sudo a2enmod headers
sudo a2enmod expires
sudo a2enmod deflate
```

### 2. Configuration du VirtualHost
Créer `/etc/apache2/sites-available/passioncrea.conf`:
```apache
<VirtualHost *:80>
    ServerName votre-domaine.com
    DocumentRoot /var/www/passioncrea
    
    <Directory /var/www/passioncrea>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
    
    ErrorLog ${APACHE_LOG_DIR}/passioncrea-error.log
    CustomLog ${APACHE_LOG_DIR}/passioncrea-access.log combined
</VirtualHost>
```

### 3. Activer le site
```bash
sudo a2dissite 000-default
sudo a2ensite passioncrea
sudo systemctl reload apache2
```

### 4. SSL (HTTPS) - Recommandé
```bash
sudo apt install certbot python3-certbot-apache
sudo certbot --apache -d votre-domaine.com
```

## Structure des Fichiers
```
passioncrea/
├── index.html          # Point d'entrée de l'application
├── .htaccess           # Configuration Apache2
├── assets/             # Fichiers JS et CSS
│   ├── index-xxxxx.js
│   └── index-xxxxx.css
└── logos/              # Images et logos
    └── Logo/
        ├── Organisation/
        └── Partenaires/
```

## Mise à Jour
Pour mettre à jour l'application:
1. Extraire la nouvelle version ZIP
2. Remplacer les fichiers dans /var/www/passioncrea/
3. Les fichiers utilisateurs (logos uploadés) sont conservés

## Dépannage

### Page blanche
- Vérifier les permissions: `sudo chown -R www-data:www-data /var/www/passioncrea/`
- Vérifier les logs Apache: `sudo tail -f /var/log/apache2/passioncrea-error.log`

### Erreur 403 Forbidden
- Vérifier que `AllowOverride All` est configuré
- Activer mod_rewrite: `sudo a2enmod rewrite`

### Images non chargées
- Vérifier les permissions du dossier logos
- Nettoyer le cache navigateur (Ctrl+F5)

## Configuration Avancée

### Performance
Pour optimiser les performances:
```bash
# Activer la compression gzip
sudo a2enmod deflate

# Configurer le cache navigateur
# (Déjà inclus dans .htaccess)
```

### Sécurité
Pour renforcer la sécurité:
```bash
# Désactiver l'indexation
Options -Indexes

# Activer HTTPS uniquement (après certbot)
```

## Support
En cas de problème, vérifier:
1. Logs Apache: `/var/log/apache2/error.log`
2. Console navigateur (F12) pour les erreurs JS
3. Permissions des fichiers et dossiers
