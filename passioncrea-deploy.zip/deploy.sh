#!/bin/bash

# PassionCréa - Script de Déploiement Apache2
# Usage: ./deploy.sh [chemin_installation]

set -e

# Couleurs pour l'affichage
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

INSTALL_PATH="${1:-/var/www/passioncrea}"

echo -e "${GREEN}🚀 Déploiement de PassionCréa${NC}"
echo "================================"

# Vérifier les privilèges root
if [ "$EUID" -ne 0 ]; then 
    echo -e "${RED}❌ Ce script doit être exécuté en tant que root${NC}"
    echo "Usage: sudo $0 [chemin_installation]"
    exit 1
fi

# Vérifier qu'Apache2 est installé
if ! command -v apache2 &> /dev/null; then
    echo -e "${YELLOW}📦 Apache2 non trouvé. Installation...${NC}"
    apt-get update
    apt-get install -y apache2
fi

# Activer les modules nécessaires
echo -e "${YELLOW}⚙️  Configuration d'Apache2...${NC}"
a2enmod rewrite headers expires deflate 2>/dev/null || true

# Créer le répertoire d'installation
echo -e "${YELLOW}📁 Préparation de l'installation...${NC}"
mkdir -p "$INSTALL_PATH"
rm -rf "${INSTALL_PATH}"/*
cp -r ./* "$INSTALL_PATH/"

# Configurer les permissions
echo -e "${YELLOW}🔒 Configuration des permissions...${NC}"
chown -R www-data:www-data "$INSTALL_PATH"
chmod -R 755 "$INSTALL_PATH"

# Activer le site
SITE_NAME=$(basename "$INSTALL_PATH")
if [ ! -f "/etc/apache2/sites-available/${SITE_NAME}.conf" ]; then
    cat > "/etc/apache2/sites-available/${SITE_NAME}.conf" << EOF
<VirtualHost *:80>
    ServerName localhost
    DocumentRoot $INSTALL_PATH
    
    <Directory $INSTALL_PATH>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
    
    ErrorLog \${APACHE_LOG_DIR}/${SITE_NAME}-error.log
    CustomLog \${APACHE_LOG_DIR}/${SITE_NAME}-access.log combined
</VirtualHost>
EOF
    a2dissite 000-default 2>/dev/null || true
    a2ensite "$SITE_NAME" 2>/dev/null || true
fi

# Recharger Apache2
echo -e "${YELLOW}🔄 Rechargement d'Apache2...${NC}"
systemctl reload apache2

echo ""
echo -e "${GREEN}✅ Déploiement terminé avec succès !${NC}"
echo "================================"
echo -e "📂 Installation: ${GREEN}$INSTALL_PATH${NC}"
echo -e "🌐 URL: ${GREEN}http://localhost${NC}"
echo ""
echo -e "${YELLOW}📝 Prochaines étapes:${NC}"
echo "   1. Configurer un nom de domaine dans le VirtualHost"
echo "   2. Activer HTTPS avec Let's Encrypt:"
echo "      sudo certbot --apache -d votre-domaine.com"
echo ""
